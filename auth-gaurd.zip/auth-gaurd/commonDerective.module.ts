// Modules
import {NgModule} from '@angular/core';
import {OnlynumberDirective} from './onlyNumber';
import {EllipsisPipe} from './ellipsis.pipe';
import {DisableRightClickDirective} from './right -click';
@NgModule({
  declarations:[
    OnlynumberDirective,
    EllipsisPipe,
    DisableRightClickDirective
  ],
  exports:[
    OnlynumberDirective,
    EllipsisPipe,
    DisableRightClickDirective
  ]
})
export class commonDerectivenModule{}
